<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="widht=device-width, initial-scale=1.0">
    <title>Sistem Perpustakaan</title>
    <style>
        body {
            font-family: arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            margin: 15px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 { color: #2c3e50; border-bottom: 3px solid #27ae60; padding-bottom: 10px; }
        .info { background: #e8f5e9; border-left: 4px solid #27ae60; padding: 12px; margin: 10px 0; }
        .info1 { background: #e8e8f5; border-left: 4px solid #273bae; padding: 12px; margin: 10px 0;}
        .server { background: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Sistem Manajemen Perpustakaan</h1>

        <div class="info">
            <h3>Selamat Datang!</h3>
            <p><strong>Dibuat oleh:</strong> <?php echo "Lintang Tsaniatu Azzahro"; ?></p>
            <p><strong>Tanggal: </strong> <?php echo date('d F Y'); ?></p>
            <p><strong>Waktu server: </strong> <?php echo date ('H:i:s'); ?></p>
        </div>

        <div class="server">
            <h3>Informasi Server</h3>
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
            <p><strong>Server Software: </strong> <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
            <p><strong>Document Root:</strong> <?php echo $_SERVER['DOCUMENT_ROOT']; ?></p>
        </div>

        <?php 
        //Data statis - belum dari database
        $nama_perpus        = "Perpustakaan Universitas ABC";
        $total_buku         = 1250;
        $total_anggota      = 450;
        $buku_dipinjam      = 178;
        $buku_tersedia      = $total_buku - $buku_dipinjam;
        $persen_pinjam      = round(($buku_dipinjam / $total_buku) * 100, 1);
        $alamat_perpus      = "Jl. Dr. Wachidin No.54, Kauman, Kec.Batang, Kabupaten Batang, Jawa Tengah";
        $telepon_perpus     = "19087786";
        $jam_buka           = "09.00";
        $jam_tutup          = "16.00";
        $persen_tersedia    = round (($buku_tersedia / $total_buku) * 100, 1);
        ?>

        <div class="info1">
            <h3>Informasi <?php echo $nama_perpus; ?></h3>
            <p><strong>Alamat:</strong> <?php echo $alamat_perpus; ?></p>
            <p><strong>Telepon:</strong> <?php echo $telepon_perpus; ?></p>
            <p><strong>Jam Operasional:</strong> <?php echo $jam_buka; ?> s/d <?php echo $jam_tutup; ?></p>
            <p><strong>Hari Libur:</strong> <?php echo "Sabtu-Minggu"; ?></p>
        </div>

        <div class="info">
            <h3>Statistik <?php echo $nama_perpus; ?></h3>
            <p><strong>Total Buku:</strong> <?php echo number_format($total_buku); ?> buku</p>
            <p><strong>Total Anggota:</strong> <?php echo number_format($total_anggota); ?> orang</p>
            <p><strong>Sedang Dipinjam:</strong> <?php echo $buku_dipinjam; ?> buku (<?php echo $persen_pinjam; ?>%)</p>
            <p><strong>Tersedia:</strong> <?php echo number_format($buku_tersedia); ?> buku (<?php echo $persen_tersedia; ?>%)</p>
        </div>
    </div>
</body>
</html>